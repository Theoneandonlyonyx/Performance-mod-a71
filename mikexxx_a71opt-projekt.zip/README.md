# Mikexxx A71 Optimizer (Forge 1.20.1)

Client-Mod fuer Minecraft Java auf dem Samsung A71 (MJLauncher, Renderer LTW, Shader).

## Bauen
1. Alles aus dieser ZIP in ein GitHub-Repository hochladen (Ordner `mod/` und `.github/` im Hauptverzeichnis).
2. Reiter "Actions" -> Workflow "build-jar" laeuft automatisch (oder "Run workflow").
3. Unten beim fertigen Lauf unter "Artifacts" `mikexxx_a71opt-jar` laden, entpacken.
4. Die Datei `mikexxx_a71opt-1.0.0.jar` in den `mods`-Ordner der Instanz legen.

## Was die Mod macht
- **A71-Profil** (einmalig beim ersten Start): Renderdistanz 5, Simulationsdistanz 5, 60 FPS-Limit, Grafik "Schnell",
  weniger Partikel, Wolken aus, Entity-Schatten aus, kurze Entity-Sichtweite, Biom-Uebergang 1.
- **Spawn-Chunks verkleinern**: Vanilla haelt um den Welt-Spawn dauerhaft einen riesigen Bereich geladen. Das wird
  nach dem Start auf Radius 2 gesenkt (weniger RAM, weniger Tick-Last, viel kuerzeres Speichern).
- **Adaptive Renderdistanz**: startet beim Betreten einer Welt klein und faehrt schrittweise hoch, senkt bei
  Lag (FPS unter 75 % vom Ziel oder Server-Tick ueber 45 ms) und lernt eine Obergrenze.
- **HUD** oben links: FPS, Server-Tickzeit, Renderdistanz, RAM.
- **Bericht** `config/mikexxx_a71opt-bericht.txt`: Heap, Geraete-RAM, Kerne, Grafik, Mod-Hinweise.

## Befehle (im Chat)
`/a71 status`, `/a71 hud`, `/a71 auto`, `/a71 rd <n>`, `/a71 ziel <fps>`, `/a71 profil`, `/a71 report`, `/a71 spawn`

## Einstellungen
`config/mikexxx_a71opt-client.toml` (Ziel-FPS, Renderdistanz-Grenzen, Profilwerte, Spawn-Radius, HUD an/aus).
